package com.example.evaluacionintermediamoduloiii;

import android.app.AlertDialog;
import android.app.FragmentTransaction;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;

import com.example.evaluacionintermediamoduloiii.ui.login.LoginActivity;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;

import android.view.SurfaceControl;
import android.view.View;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private EditText nombre;
    private EditText telefono;
    private ListView listaclientes;
    private ArrayList contacto;
    private ArrayAdapter<String> adaptador;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        nombre = (EditText) findViewById(R.id.txt_nombre);
        telefono = (EditText) findViewById(R.id.txt_numero);
        listaclientes = (ListView) findViewById(R.id.lista);
        contacto = new ArrayList<String>();


        listaclientes.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {

            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, final int i, long l) {
                final int posicion = i;
                AlertDialog.Builder dialogo1 = new AlertDialog.Builder((view.getContext()));
                dialogo1.setTitle("Cuidado!");
                dialogo1.setMessage("¿ Estas seguro de eliminar tu contacto ?");
                dialogo1.setCancelable(false);
                dialogo1.setPositiveButton("Confirmar", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialogo1, int id) {
                        contacto.remove(posicion);
                        adaptador.notifyDataSetChanged();
                        Toast.makeText(getApplicationContext(), "Contacto Eliminado.",
                                Toast.LENGTH_SHORT).show();
                    }

                });

                dialogo1.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialogo1, int id) {
                    }
                });
                dialogo1.show();

                return false;
            }

        });

    }

    public void agregar(View vista) {
        contacto.add(nombre.getText().toString() + " " + telefono.getText().toString());
        nombre.setText("");
        telefono.setText("");
        adaptador = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, contacto);
        listaclientes.setAdapter(adaptador);

    }

  @Override
    public boolean onCreateOptionsMenu(Menu menu) {                 //boton del toolbar
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.agenda) {
            Intent irAgenda=new Intent(this, SegundaActividad.class);
            startActivity(irAgenda);
        }
        if (id==R.id.salir){
            finishAffinity();
        }
        return super.onOptionsItemSelected(item);
    }

}
