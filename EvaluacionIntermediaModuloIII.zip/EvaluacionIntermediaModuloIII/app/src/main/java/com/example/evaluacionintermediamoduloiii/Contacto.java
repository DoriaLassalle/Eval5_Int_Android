package com.example.evaluacionintermediamoduloiii;

public class Contacto {
    public String nombre;
    public String apellido;
    public int edad;
    public String fechaNac;

    public Contacto(String nombre, String apellido, String fechaNac, String s){
        ingNombre();
        ingApellido();
        ingFechaNac();
        ingEdad();
    }

    public Contacto(String nombre, String apellido,  String fechaNac, int edad) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.fechaNac = fechaNac;
        this.edad = edad;
    }
    public String ingNombre(){
        this.nombre=getNombre();

        return nombre;
    }
    public String ingApellido(){
        this.apellido=getApellido();
        return apellido;
    }
    public String ingFechaNac(){
        this.fechaNac=getFechaNac();
        return fechaNac;
    }
    public int ingEdad(){
        this.edad=getEdad();
        return edad;
    }


    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public int getEdad() {
        return edad;
    }

    public String getFechaNac() {
        return fechaNac;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public void setFechaNac(String fechaNac) {
        this.fechaNac = fechaNac;
    }
}
