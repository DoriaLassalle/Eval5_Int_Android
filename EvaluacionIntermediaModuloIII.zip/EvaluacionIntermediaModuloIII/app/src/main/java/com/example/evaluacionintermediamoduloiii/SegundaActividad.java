package com.example.evaluacionintermediamoduloiii;

import androidx.annotation.ContentView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.app.FragmentTransaction;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.sql.Wrapper;
import java.util.ArrayList;

import static com.example.evaluacionintermediamoduloiii.R.*;
import static com.example.evaluacionintermediamoduloiii.R.id.age;
import static com.example.evaluacionintermediamoduloiii.R.id.agenda;


public class SegundaActividad extends AppCompatActivity {

    private EditText nom;
    private EditText apell;
    private EditText fecha;
    private EditText edad;
    private Button btn_guardarCont;
    private ListView listaContactos;
    private ArrayList<String> agenda=new ArrayList<String>();
    private ArrayAdapter<String> adaptador;
    private Integer indice;
    private String listado;
    private Button actualizar;
    private Button eliminar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(layout.activity_segunda_actividad);

        nom = (EditText) findViewById(R.id.name);
        apell = (EditText) findViewById(R.id.lastname);
        fecha = (EditText) findViewById(R.id.born);
        edad = (EditText) findViewById(R.id.age);
        btn_guardarCont =(Button)findViewById(R.id.save);
        listaContactos =(ListView)findViewById(id.listAgenda);
        actualizar=(Button)findViewById(id.update);
        eliminar=(Button)findViewById(id.delete);

        adaptador=new ArrayAdapter<>(getApplicationContext(),
                android.R.layout.simple_list_item_single_choice,agenda);
        listaContactos.setAdapter(adaptador);                           //paso el adap al lv


        View.OnClickListener agregar =new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (nom.getText().toString().isEmpty() || apell.getText().toString().isEmpty() ||
                        fecha.getText().toString().isEmpty() || edad.getText().toString().isEmpty()){
                    Toast.makeText(getApplicationContext(), "Ingresa Todos los Datos!",
                            Toast.LENGTH_LONG).show();

                }else {
                    agenda.add(nom.getText().toString() + " " + apell.getText().toString() + ", F.Nac: " +
                            fecha.getText().toString() + ", Edad: " + edad.getText().toString() + " años.");
                    nom.setText("");
                    apell.setText("");
                    fecha.setText("");
                    edad.setText("");
                    adaptador.notifyDataSetChanged();
                    Toast.makeText(getApplicationContext(), "Cliente agregado con éxito!",
                            Toast.LENGTH_SHORT).show();
                }
            }
       };
        listaContactos.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                listado= adapterView.getItemAtPosition(i).toString()+" Seleccionado...";
                indice=i;
                Toast.makeText(getApplicationContext(), listado, Toast.LENGTH_SHORT).show();

            }
        });
        actualizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String name=nom.getText().toString();
                String last=apell.getText().toString();
                String date=fecha.getText().toString();
                String primaveras=edad.getText().toString();

                if (indice==null || name.equals("") || last.equals("") ||date.equals("") ||
                        primaveras.equals("") ||agenda.isEmpty()){
                    Toast.makeText(getApplicationContext(), "Completa Todos los Campos!",
                           Toast.LENGTH_LONG).show();
               }else {
                        agenda.set(indice, name+ " " + last+ ", F.Nac: " +
                                date+ ", Edad: " + primaveras+ " años.");
                        nom.setText("");
                        apell.setText("");
                        fecha.setText("");
                        edad.setText("");
                        adaptador.notifyDataSetChanged();
                        Toast.makeText(getApplicationContext(), "Datos Actualizados!",
                                Toast.LENGTH_LONG).show();
                }
            }

        });
        eliminar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final int position=indice;
                agenda.remove(position);
                adaptador.notifyDataSetChanged();
                Toast.makeText(getApplicationContext(), "Cliente Eliminado!",
                        Toast.LENGTH_SHORT).show();

            }
        });

        btn_guardarCont.setOnClickListener(agregar);
        listaContactos.setAdapter(adaptador);

    }


}